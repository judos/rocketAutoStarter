require("config")
require("prototypes.basic-lua-extensions")
require("prototypes.functions")

require("prototypes.entity")
require("prototypes.items")
require("prototypes.recipe")
require("prototypes.technology")