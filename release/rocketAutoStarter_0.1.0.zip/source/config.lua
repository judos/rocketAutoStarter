debug_master = false -- Master switch for debugging, prints debug stuff into the shell where factorio was started from

updateEveryTicks = 10*60 -- when the packager doesn't run the next update is triggered X ticks later

messageForSentRockets = true -- send a message with the statistics of the sent rockets to all players
messageForSentRocketsEveryMinutes = 10 -- the message will be sent only if there are rockets sent in the last X ticks