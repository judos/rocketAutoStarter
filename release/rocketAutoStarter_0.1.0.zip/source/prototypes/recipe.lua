data:extend(
{
  {
    type = "recipe",
    name = "rocketAutoStarter",
    enabled = "false",
    ingredients =
    {
      {"steel-plate", 5},
      {"electronic-circuit", 10},
      {"copper-cable", 5},
    },
    result = "rocketAutoStarter",
    energy_required = 1,
  },
})