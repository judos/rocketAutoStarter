data:extend({
	{
		type = "item",
		name = "rocketAutoStarter",
		icon = "__rocketAutoStarter__/graphics/icons/rocketAutoStarter.png",
		place_result = "rocketAutoStarter",
		flags = {"goes-to-quickbar"},
    subgroup = "defensive-structure",
		category = "crafting",
		order = "0",
		stack_size = 50,
	},
})