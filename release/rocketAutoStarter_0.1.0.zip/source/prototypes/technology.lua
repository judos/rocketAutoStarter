addTechnologyUnlocksRecipe("rocket-silo","rocketAutoStarter")

