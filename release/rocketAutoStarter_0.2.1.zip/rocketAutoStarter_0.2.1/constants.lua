
modVersion = "0.2.1"
modName = "rocketAutoStarter"
fullModName = "rocketAutoStarter"

libLog.testing = false -- enable logging (player console output)