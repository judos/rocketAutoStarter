
updateEveryTicks = 10*60 -- the next update is triggered X ticks later

messageForSentRockets = true -- send a message with the statistics of the sent rockets to all players
messageForSentRocketsEveryMinutes = 10 -- the message will be sent only if there are rockets sent in the last X ticks
