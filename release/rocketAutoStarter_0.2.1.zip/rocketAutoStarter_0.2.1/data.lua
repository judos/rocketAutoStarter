require "config"
require "libs.functions"

require "prototypes.entity"
require "prototypes.items"
require "prototypes.recipe"
require "prototypes.technology"